import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { ThemeProvider } from "@/components/theme-provider";
import AppLayout from "@/components/layout/AppLayout";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import FileUpload from "./pages/FileUpload";
import Reconciliation from "./pages/Reconciliation";
import Exceptions from "./pages/Exceptions";
import SpanAnalysis from "./pages/SpanAnalysis";
import OtcProcessing from "./pages/OtcProcessing";
import AuditTrail from "./pages/AuditTrail";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <HelmetProvider>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppLayout>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/upload" element={<FileUpload />} />
                <Route path="/reconciliation" element={<Reconciliation />} />
                <Route path="/exceptions" element={<Exceptions />} />
                <Route path="/span" element={<SpanAnalysis />} />
                <Route path="/otc" element={<OtcProcessing />} />
                <Route path="/audit" element={<AuditTrail />} />
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </AppLayout>
          </BrowserRouter>
        </TooltipProvider>
      </ThemeProvider>
    </HelmetProvider>
  </QueryClientProvider>
);

export default App;
